import {NextRequest,NextResponse} from "next/server";
import {createClient} from "@/lib/supabase-server";
import {createClient as createServiceClient} from "@supabase/supabase-js";
import {saveTwelveDataKey,getTwelveDataKey} from "@/lib/secrets";
async function isAdmin(){
  const auth=createClient(); const {data:{user}}=await auth.auth.getUser();
  return !!user && user.app_metadata?.role==="admin";
}
export async function GET(){
  if(!await isAdmin()) return NextResponse.json({error:"Forbidden"},{status:403});
  try { const key=await getTwelveDataKey(); return NextResponse.json({configured:!!key,masked:key?"Configured ••••••••":"Not configured"}); }
  catch { return NextResponse.json({configured:false,masked:"Configuration unavailable"},{status:503}); }
}
export async function POST(req:NextRequest){
  if(!await isAdmin()) return NextResponse.json({error:"Forbidden"},{status:403});
  let body:any; try { body=await req.json(); } catch { return NextResponse.json({error:"Invalid request"},{status:400}); }
  const key=typeof body?.apiKey==="string"?body.apiKey.trim():"";
  if(key.length<20 || key.length>300 || /\s/.test(key)) return NextResponse.json({error:"Enter a valid provider key."},{status:400});
  try { await saveTwelveDataKey(key); return NextResponse.json({saved:true,message:"Provider key securely updated. The key will not be shown again."}); }
  catch { return NextResponse.json({error:"Unable to save key. Check server configuration."},{status:503}); }
}
