import {NextResponse} from "next/server";
import {createClient} from "@/lib/supabase-server";
export async function GET(){
  const supabase=createClient();const {data:{user}}=await supabase.auth.getUser();
  if(!user||user.app_metadata?.role!=="admin")return NextResponse.json({error:"Forbidden"},{status:403});
  // Intentionally return no password fields. Authentication passwords are never readable by admins.
  return NextResponse.json({message:"Admin session verified. Member directory can be connected to a profile table with row-level security.",members:[]});
}
